#!/bin/bash
#sleep 1
/home/sylow/Downloads/reso.sh $
#xrandr -s 1366x768_60 $
tint2 $
#nitrogen --restore $
#pnmixer $
/usr/bin/lxpolkit $
